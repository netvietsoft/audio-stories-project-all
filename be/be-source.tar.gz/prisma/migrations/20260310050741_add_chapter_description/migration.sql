-- AlterTable
ALTER TABLE `chapters` ADD COLUMN `description` TEXT NULL;
