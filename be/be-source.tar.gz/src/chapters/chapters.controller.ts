import {
    Controller,
    Get,
    Post,
    Body,
    Patch,
    Param,
    Delete,
    UseGuards,
    Query,
} from '@nestjs/common';
import { ChaptersService } from './chapters.service';
import { CreateChapterDto } from './dto/create-chapter.dto';
import { CreateStandaloneChapterDto } from './dto/create-standalone-chapter.dto';
import { UpdateChapterDto } from './dto/update-chapter.dto';
import { ChapterQueryDto } from './dto/chapter-query.dto';
import { JwtAccessGuard } from '@/auth/guards/jwt-access.guard';
import { RolesGuard } from '@/auth/guards/roles.guard';
import { Roles } from '@/auth/decorators/roles.decorator';
import { Public } from '@/auth/decorators/public.decorator';

@Controller()
export class ChaptersController {
    constructor(private readonly chaptersService: ChaptersService) { }

    @Get('stories/:storyId/chapters')
    @UseGuards(JwtAccessGuard, RolesGuard)
    @Roles('ADMIN')
    findAll(@Param('storyId') storyId: string) {
        return this.chaptersService.findAllByStory(storyId);
    }

    @Post('stories/:storyId/chapters')
    @UseGuards(JwtAccessGuard, RolesGuard)
    @Roles('ADMIN')
    create(
        @Param('storyId') storyId: string,
        @Body() createChapterDto: CreateChapterDto,
    ) {
        return this.chaptersService.create(storyId, createChapterDto);
    }

    @Post('chapters')
    @UseGuards(JwtAccessGuard, RolesGuard)
    @Roles('ADMIN')
    createStandalone(@Body() createChapterDto: CreateStandaloneChapterDto) {
        return this.chaptersService.createStandalone(createChapterDto);
    }

    @Public()
    @Get('chapters/latest')
    getLatest(
        @Query('limit') limit?: string,
        @Query('lang') lang?: string,
    ) {
        return this.chaptersService.findLatest(Number(limit) || 12, lang);
    }

    @Get('chapters')
    @UseGuards(JwtAccessGuard, RolesGuard)
    @Roles('ADMIN')
    findAllGlobal(@Query() query: ChapterQueryDto) {
        return this.chaptersService.findAllGlobal(query);
    }

    @Get('chapters/:id')
    @UseGuards(JwtAccessGuard, RolesGuard)
    @Roles('ADMIN')
    findOne(@Param('id') id: string) {
        return this.chaptersService.findOne(id);
    }

    @Patch('chapters/:id')
    @UseGuards(JwtAccessGuard, RolesGuard)
    @Roles('ADMIN')
    update(@Param('id') id: string, @Body() updateChapterDto: UpdateChapterDto) {
        return this.chaptersService.update(id, updateChapterDto);
    }

    @Delete('chapters/:id')
    @UseGuards(JwtAccessGuard, RolesGuard)
    @Roles('ADMIN')
    remove(@Param('id') id: string) {
        return this.chaptersService.remove(id);
    }
}
